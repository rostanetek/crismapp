<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{facebookcomments}prestashop>facebookcomments_3a3f8a7ff90a73aec5ebd661bc92b048'] = 'Facebook Kommentare.';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_6ae34f196a8c618f2f9778ea75a41f3d'] = 'Eine einfachste Weg, um facebook Kommentare hinzufügen Plugin für Ihren prestashop Shop';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_7278125be8c9aceaaf5d3f7645b45c5c'] = 'Einstellungen gespeichert';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_75fa820aebc10bf31b310065b38447c7'] = 'Produkt-Tabs';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_9787028383eef1dfde2f09093a851373'] = 'Produkt-Footer';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_9235843ddcf97caf4b7c712dbc95d045'] = 'Kommentare Einlaufbreite';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_0f2898ac15073825a5c5d88723264685'] = 'Anzahl Kommentare';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_2ac43aa43bf473f9a9c09b4b608619d3'] = 'Licht Farben';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_a82fd95db10ff25dfad39f07372ebe37'] = 'dunkle Farben';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_4994a8ffeba4ac3140beb89e8d41f174'] = 'Sprache';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_3124e63231a4594958d87771b4aaf064'] = 'Administratoren';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_3d21e9d303e562c108fdb16f576a8ad6'] = 'Trennen Sie alle Admin-IDs durch Kommas';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_498723c00388358f83d6586606edd577'] = 'APP-ID';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_aee345f5ca3a8198dc27a4475cb2c824'] = 'Sie können eigene Facebook App';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_9daf1fb753b42c3cdc8f1d01669cd6d8'] = 'Einstellungen speichern';
$_MODULE['<{facebookcomments}prestashop>tab_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Einstellungen speichern';
