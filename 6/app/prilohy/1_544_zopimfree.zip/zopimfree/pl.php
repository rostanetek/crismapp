<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{facebookcomments}prestashop>facebookcomments_3a3f8a7ff90a73aec5ebd661bc92b048'] = 'Komentarze Facebook';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_6ae34f196a8c618f2f9778ea75a41f3d'] = 'Najłatwiejszy i najlepszy sposób na dodanie komentarzy facebook do swoich produktów';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_7278125be8c9aceaaf5d3f7645b45c5c'] = 'Ustawienia zapisane';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_f4f70727dc34561dfde1a3c529b6205c'] = 'Ustawienia';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_75fa820aebc10bf31b310065b38447c7'] = 'Zakładki produktu';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_9787028383eef1dfde2f09093a851373'] = 'Stopka produktu';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_9235843ddcf97caf4b7c712dbc95d045'] = 'Szerokość okna komentarzy';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_0f2898ac15073825a5c5d88723264685'] = 'Liczba komentarzy';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_2ac43aa43bf473f9a9c09b4b608619d3'] = 'jasny';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_a82fd95db10ff25dfad39f07372ebe37'] = 'ciemny';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_4994a8ffeba4ac3140beb89e8d41f174'] = 'Język';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_3124e63231a4594958d87771b4aaf064'] = 'Administratorzy';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_3d21e9d303e562c108fdb16f576a8ad6'] = 'wymień id wszystkich administratorów (oddzielaj przecinkiem)';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_498723c00388358f83d6586606edd577'] = 'APP id';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_aee345f5ca3a8198dc27a4475cb2c824'] = 'możesz użyć własnej aplikacji facebook';
$_MODULE['<{facebookcomments}prestashop>facebookcomments_9daf1fb753b42c3cdc8f1d01669cd6d8'] = 'Zapisz ustawienia';
$_MODULE['<{facebookcomments}prestashop>tab_8413c683b4b27cc3f4dbd4c90329d8ba'] = 'Komentarze';
